﻿aws_region           = "us-east-1"
environment          = "poc"
vpc_cidr             = "10.0.0.0/16"
ec2_instance_type    = "t3.micro"
rds_instance_class   = "db.t3.micro"

# Database Configuration (Minimal Free Tier 20GB)
db_name              = "ticketdesk_db"
db_username          = "ticketdesk_admin"
db_password          = "TicketDesk_SecurePass2026!"

# Microservice Security Keys
jwt_secret           = "TicketDeskJwtSecretKeyForEnterprisePOC2026SecureStringMustBe256BitsLong!"
internal_service_key = "TicketDeskInternalServiceAuthSecret2026!"

allowed_admin_cidrs  = ["0.0.0.0/0"]

